import BookList from "@/app/components/BookList";
import React from "react";

const page = () => {
  return <BookList />;
};

export default page;

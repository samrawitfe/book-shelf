interface Book {
  id: number;
  title: string;
  author: string;
  coverImageUrl: string;
}

export default async function BookList() {
  const res = await fetch(
    "https://crudcrud.com/api/178684d1afef4531b2ede94d96842317"
  );
  const books: Book[] = await res.json();

  return (
    <div>
      <h1>Books</h1>
      {books.map((book: Book) => (
        <ul>
          <li key={book.id}>
            <div className="card card-compact bg-base-100 shadow-xl">
              <figure>
                <img src={book.coverImageUrl} alt={`Cover of ${book.title}`} />
              </figure>
              <div className="card-body">
                <h2 className="card-title">{book.title}</h2>
                <p>{book.author}</p>
              </div>
            </div>
          </li>
        </ul>
      ))}
    </div>
  );
}

import React from "react";

interface Props {
  imageSrc: string;
  altMessage: string;
  title: string;
  author: string;
}
const BookCard = ({ imageSrc, altMessage, title, author }: Props) => {
  return (
    <div>
      <figure>
        <img src={imageSrc} alt={`Cover of ${altMessage}`} />
      </figure>
      <div className="card-body">
        <h2 className="card-title">{title}</h2>
        <p>{author}</p>
      </div>
    </div>
  );
};

export default BookCard;

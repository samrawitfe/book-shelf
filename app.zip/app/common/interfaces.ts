export interface Book {
  title: string;
  author: string;
  coverImageUrl: string;
}
